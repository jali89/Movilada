/*
 * ScoresFragment.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.activities;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import es.uam.eps.dadm.othello_alejandromartin.R;
import es.uam.eps.dadm.othello_alejandromartin.model.Round;
import es.uam.eps.dadm.othello_alejandromartin.model.RoundRepository;
import es.uam.eps.dadm.othello_alejandromartin.model.RoundRepositoryFactory;
import es.uam.eps.multij.ExcepcionJuego;

/**
 * La clase ScoresFragment es la actividad en la cual se muestra la lista de rondas finalizadas.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class ScoresFragment extends Fragment {

    private RecyclerView roundRecyclerView;
    private ScoresFragment.RoundAdapter roundAdapter;

    /**
     * Metodo que crea la lista de fragmentos.
     * @param savedInstanceState objeto de tipo Builder que permite configurar la lista de
     *                          fragmentos.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    /**
     * Metodo llamado cuando la interfaz dela lista de fragmentos se diseña por primera vez.
     * @param inflater inflador de la vista de la lista de fragmentos.
     * @param container contenedor de la vista de la lista de fragmentos.
     * @param savedInstanceState objeto de tipo Builder que permite configurar la lista de
     *                           fragmentos.
     * @return View creada.
     */
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_round_list, container, false);

        roundRecyclerView = (RecyclerView) view.findViewById(R.id.round_recycler_view);
        RecyclerView.LayoutManager linearLayoutManager = new
                LinearLayoutManager(getActivity());

        roundRecyclerView.setLayoutManager(linearLayoutManager);
        roundRecyclerView.setItemAnimator(new DefaultItemAnimator());

        updateUI();

        return view;
    }

    /**
     * Metodo para retomar una lista de fragmentos.
     */
    @Override
    public void onResume() {
        super.onResume();
        updateUI();
    }

    /**
     * Metodo para actualizar la interfaz de la lista de fragmentos.
     */
    public void updateUI() {
        RoundRepository repository = RoundRepositoryFactory.createRepository(getActivity());
        try {
            repository.getFinishedRounds(OthelloPreferenceActivity.getPlayerUUID(getActivity()),
                    null, null, new RoundRepository.RoundsCallback() {
                @Override
                public void onResponse(List<Round> rounds) {
                    roundAdapter = new ScoresFragment.RoundAdapter(rounds);
                    roundRecyclerView.setAdapter(roundAdapter);
                }

                @Override
                public void onError(String error) {
                    Toast.makeText(getContext(), error, Toast.LENGTH_SHORT).show();

                }
            });
        } catch (ExcepcionJuego excepcionJuego) {
            excepcionJuego.printStackTrace();
        }

    }

    /**
     * Clase RoundAdapter para manejar la lista de fragmentos.
     */
    public class RoundAdapter extends RecyclerView.Adapter<ScoresFragment.RoundAdapter.RoundHolder> {

        private List<Round> rounds;

        /**
         * Clase RoundHolder que gestionara la clase RoundAdapter para mantener actualizada
         * la lista de fragmentos.
         */
        public class RoundHolder extends RecyclerView.ViewHolder {

            private TextView idTextView;
            private TextView boardTextView;
            private TextView dateTextView;

            private Round round;

            /**
             * Constructor de la clase RoundHolder.
             * @param itemView vista que se quiere gestionar.
             */
            public RoundHolder(View itemView) {
                super(itemView);
                idTextView = (TextView) itemView.findViewById(R.id.list_item_id);
                boardTextView = (TextView) itemView.findViewById(R.id.list_item_board);
                dateTextView = (TextView) itemView.findViewById(R.id.list_item_date);
            }

            /**
             * Metodo que enlaza con una ronda.
             * @param round ronda indicada con la cual se va a enlazar.
             */
            public void bindRound(Round round){
                this.round = round;
                idTextView.setText(round.getTitle());
                int white_score = round.getBoard().getPuntosJug1();
                int black_score = round.getBoard().getPuntosJug2();
                boardTextView.setText(round.getFirstPlayerName() + " " +
                        String.valueOf(white_score) + "\n" +
                        round.getSecondPlayerName() + " " +
                        String.valueOf(black_score));
                dateTextView.setText(String.valueOf(round.getDate()).substring(0,19));
            }
        }

        /**
         * Constructor de la clase RoundAdapter.
         * @param rounds lista de rondas que va a gestionar.
         */
        public RoundAdapter(List<Round> rounds){
            this.rounds = rounds;
        }

        /**
         * Metodo para crear la vista de un RoundHolder a partir de un RoundAdapter.
         * @param parent clase padre.
         * @param viewType tipo de vista.
         * @return RoundAdapter.RoundHolder, para gestionar la clase RoundAdapter y
         * mantener actualizada la lista de fragmentos.
         */
        @Override
        public ScoresFragment.RoundAdapter.RoundHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
            View view = layoutInflater.inflate(R.layout.list_item_round, parent, false);
            return new ScoresFragment.RoundAdapter.RoundHolder(view);
        }

        /**
         * Metodo que enlaza con una ronda.
         * @param holder gestor de la ronda.
         * @param position posicion de la ronda seleccionada.
         */
        @Override
        public void onBindViewHolder(RoundHolder holder, int position) {
            Round round = rounds.get(position);
            holder.bindRound(round);
        }

        /**
         * Metodo para obtener el numero de rondas que contiene la clase.
         * @return numero de rondas.
         */
        @Override
        public int getItemCount() {
            return rounds.size();
        }

    }
}
