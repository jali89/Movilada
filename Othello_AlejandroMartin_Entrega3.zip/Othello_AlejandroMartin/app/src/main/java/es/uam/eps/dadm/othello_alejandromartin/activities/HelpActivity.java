/*
 * HelpActivity.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import es.uam.eps.dadm.othello_alejandromartin.R;

/**
 * La clase HelpActivity permite mostrar al usuario una actividad con las reglas del juego.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class HelpActivity extends AppCompatActivity {

    /**
     * Metodo onCreate que crea la actividad cuando se llama a esta activity.
     * @param savedInstanceState objeto de tipo Builder que permite configurar la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);
    }

}
