/*
 * OthelloDataBase.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import es.uam.eps.dadm.othello_alejandromartin.R;
import es.uam.eps.dadm.othello_alejandromartin.model.Round;
import es.uam.eps.dadm.othello_alejandromartin.model.RoundRepository;
import es.uam.eps.dadm.othello_alejandromartin.model.TableroOthello;
import es.uam.eps.multij.ExcepcionJuego;

import static es.uam.eps.dadm.othello_alejandromartin.database.RoundDataBaseSchema.UserTable;
import static es.uam.eps.dadm.othello_alejandromartin.database.RoundDataBaseSchema.RoundTable;

/**
 * La clase OthelloDataBase permite gestionar la base de datos de la aplicacion.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class OthelloDataBase implements RoundRepository {

    private final String DEBUG_TAG = "DEBUG";
    private static final String DATABASE_NAME = "othello.db";
    private static final int DATABASE_VERSION = 1;
    private DatabaseHelper helper;
    private SQLiteDatabase db;

    /**
     * Constructor de la clase OthelloDataBase.
     * @param context contexto desde el cual se llama para crear la base de datos.
     */
    public OthelloDataBase(Context context) {
        helper = new DatabaseHelper(context);
    }

    /**
     * Crear la base de datos y actualizarla cuando sea necesario.
     */
    /**
     * La clase DatabaseHelper permite crear y actualizar la base de datos cuando sea necesario.
     *
     * @author Alejandro Antonio Martin Almansa
     */
    private static class DatabaseHelper extends SQLiteOpenHelper {

        /**
         * Constructor de la clase DatabaseHelper.
         * @param context contexto desde el cual se llama para crear el objeto.
         */
        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        /**
         * Metodo al cual se llama cuando se crea el objeto de tipo DatabaseHelper.
         * @param db base de datos a crear.
         */
        public void onCreate(SQLiteDatabase db) {
            createTable(db);
        }

        /**
         * Metodo al cual se llama cuando se actualiza la base de datos.
         * @param db base de datos a actualizar.
         * @param oldVer version antigua de la base de datos.
         * @param newVer version nueva de la base de datos.
         */
        public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
            db.execSQL("DROP TABLE IF EXISTS " + UserTable.NAME);
            db.execSQL("DROP TABLE IF EXISTS " + RoundTable.NAME);
            createTable(db);
        }

        /**
         * Metodo para crear las tabla de la base de datos.
         * @param db base de datos en la cual se van a crear.
         */
        private void createTable(SQLiteDatabase db) {
            String str1 = "CREATE TABLE " + UserTable.NAME + " ("
                    + "_id integer primary key autoincrement, "
                    + UserTable.Cols.PLAYERUUID + " TEXT UNIQUE, "
                    + UserTable.Cols.PLAYERNAME + " TEXT UNIQUE, "
                    + UserTable.Cols.PLAYERPASSWORD + " TEXT);";
            String str2 = "CREATE TABLE " + RoundTable.NAME + " ("
                    + "_id integer primary key autoincrement, "
                    + RoundTable.Cols.ROUNDUUID + " TEXT UNIQUE, "
                    + RoundTable.Cols.PLAYERUUID + " TEXT REFERENCES "+UserTable.Cols.PLAYERUUID + ", "
                    + RoundTable.Cols.DATE + " TEXT, "
                    + RoundTable.Cols.TITLE + " TEXT, "
                    + RoundTable.Cols.SIZE + " TEXT, "
                    + RoundTable.Cols.BOARD + " TEXT);";
            try {
                db.execSQL(str1);
                db.execSQL(str2);
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }

    /**
     * Invoca al metodo getWritableDatabase que devuelve la referencia de tipo SQLiteDatabase,
     * para asi modificar los datos.
     * @throws SQLException excepcion que lanza en caso de error.
     */
    @Override
    public void open() throws SQLException {
        db = helper.getWritableDatabase();
    }

    /**
     * Cierra la base de datos.
     */
    public void close() {
        db.close();
    }

    /**
     * Metodo que se llama cuando un usuario hace login en el sistema.
     * @param playername nombre del usuario.
     * @param playerpassword password del usuario.
     * @param callback al cual se llamara una vez realizado el login.
     */
    @Override
    public void login(String playername, String playerpassword,
                      LoginRegisterCallback callback) {

        Log.d(DEBUG_TAG, "Login " + playername);
        Cursor cursor = db.query(UserTable.NAME,
                new String[]{UserTable.Cols.PLAYERUUID},
                UserTable.Cols.PLAYERNAME + " = ? AND " + UserTable.Cols.PLAYERPASSWORD + " = ?",
                new String[]{playername, playerpassword}, null, null, null);

        int count = cursor.getCount();
        String uuid = count == 1 && cursor.moveToFirst() ? cursor.getString(0) : "";
        cursor.close();

        if (count == 1)
            callback.onLogin(uuid);
        else
            callback.onError(String.valueOf(R.string.user_or_pass_inco));

    }

    /**
     * Metodo que se llama cuando un usuario se registra en el sistema.
     * @param playername nombre del usuario.
     * @param password password del usuario.
     * @param callback al cual se llamara una vez realizado el registro.
     */
    @Override
    public void register(String playername, String password,
                         LoginRegisterCallback callback) {

        ContentValues values = new ContentValues();
        String uuid = UUID.randomUUID().toString();
        values.put(UserTable.Cols.PLAYERUUID, uuid);
        values.put(UserTable.Cols.PLAYERNAME, playername);
        values.put(UserTable.Cols.PLAYERPASSWORD, password);
        long id = db.insert(UserTable.NAME, null, values);

        if (id < 0)
            callback.onError(String.valueOf(R.string.err_insert_player) + " " + playername);
        else
            callback.onLogin(uuid);
    }

    /**
     * Metodo para obtener los valores de una ronda a partir de esta.
     * @param round ronda de la cual se quieren obtener los valores.
     * @return valores de la ronda.
     */
    private ContentValues getContentValues(Round round) {
        ContentValues values = new ContentValues();
        values.put(RoundTable.Cols.PLAYERUUID, round.getPlayerUUID());
        values.put(RoundTable.Cols.ROUNDUUID, round.getId());
        values.put(RoundTable.Cols.DATE, round.getDate());
        values.put(RoundTable.Cols.TITLE, round.getTitle());
        values.put(RoundTable.Cols.SIZE, round.getSize());
        values.put(RoundTable.Cols.BOARD, round.getBoard().tableroToString());

        return values;
    }

    /**
     * Metodo para obtener los valores de un usuario a partir de un usario.
     * @param playerid id del usuario que se quiere obtener.
     * @param playername nombre de usuario del usuario que se quiere obtener.
     * @param password contrasena del usuario que se quiere obtener.
     * @return valores del usuario.
     */
    private ContentValues getContentValuesPlayer (String playerid, String playername, String password) {
        ContentValues values = new ContentValues();
        values.put(UserTable.Cols.PLAYERUUID, playerid);
        values.put(UserTable.Cols.PLAYERNAME, playername);
        values.put(UserTable.Cols.PLAYERPASSWORD, password);

        return values;
    }

    /**
     * 	Anade a la base de datos la partida pasada como primer argumento.
     * @param round ronda para anadir a la base de datos.
     * @param callback al cual se llamara una vez anadida la ronda.
     */
    @Override
    public void addRound(Round round, BooleanCallback callback) {
        ContentValues values = getContentValues(round);
        long id = db.insert(RoundTable.NAME, null, values);

        if (callback != null)
            callback.onResponse(id >= 0);
    }

    /**
     * Metodo para actualizar una ronda de la base de datos.
     * @param round ronda que se quiere actualizar.
     * @param callback al cual se llamara una vez acutalizada la ronda.
     */
    @Override
    public void updateRound(Round round, BooleanCallback callback) {
        ContentValues values = getContentValues(round);
        long id = db.update(RoundTable.NAME, values, RoundTable.Cols.ROUNDUUID + " = '" + round.getId() + "'", null);

        if (callback != null)
            callback.onResponse(id >= 0);
    }

    /**
     * Metodo para actualizar un usuario de la base de datos.
     * @param playerid id del usuario que se quiere actualizar.
     * @param newUsername nombre de usuario del usuario que se quiere actualizar.
     * @param password contrasena del usuario que se quiere actualizar.
     * @param callback al cual se llamara una vez actualizado el usuario.
     */
    @Override
    public void updateUsername(String playerid, String newUsername, String password, BooleanCallback callback) {
        ContentValues values = getContentValuesPlayer(playerid, newUsername, password);
        long id = db.update(UserTable.NAME, values, UserTable.Cols.PLAYERUUID + " = '" + playerid + "'", null);

        if (callback != null)
            callback.onResponse(id >= 0);
    }

    /**
     * Metodo para obtener los valores de las tablas de un determinado usuario.
     * @return tuplas seleccionadas.
     */
    private RoundCursorWrapper queryRounds() {
        String sql = "SELECT " + UserTable.Cols.PLAYERNAME + ", " +
                UserTable.Cols.PLAYERUUID + ", " +
                RoundTable.Cols.ROUNDUUID + ", " +
                RoundTable.Cols.DATE + ", " +
                RoundTable.Cols.TITLE + ", " +
                RoundTable.Cols.SIZE + ", " +
                RoundTable.Cols.BOARD + " " +
                "FROM " + UserTable.NAME + " AS p, " +
                RoundTable.NAME + " AS r " +
                "WHERE " + "p." + UserTable.Cols.PLAYERUUID + "=" +
                "r." + RoundTable.Cols.PLAYERUUID + ";";
        Cursor cursor = db.rawQuery(sql, null);
        return new RoundCursorWrapper(cursor);
    }

    /**
     * Metodo para obtener las rondas de un determinado usuario.
     * @param playeruuid id del usuario que se quieren obtener las rondas.
     * @param orderByField orden en el que se quieren que se devuelvan.
     * @param group si se quieren agrupar.
     * @param callback al cual se llama una vez obtenidas las rondas.
     * @throws ExcepcionJuego excepcion que lanza si se produce un error.
     */
    @Override
    public void getRounds(String playeruuid, String orderByField, String group,
                          RoundsCallback callback) throws ExcepcionJuego {
        List<Round> rounds = new ArrayList<>();
        RoundCursorWrapper cursor = queryRounds();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Round round = cursor.getRound();
            if (round.getPlayerUUID().equals(playeruuid))
                rounds.add(round);
            cursor.moveToNext();
        }
        cursor.close();
        if (cursor.getCount() > 0)
            callback.onResponse(rounds);
    }

    /**
     * Metodo para obtener las rondas de un determinado usuario que esten finalizadas.
     * @param playeruuid id del usuario que se quieren obtener las rondas.
     * @param orderByField orden en el que se quieren que se devuelvan.
     * @param group si se quieren agrupar.
     * @param callback al cual se llama una vez obtenidas las rondas finalizadas.
     * @throws ExcepcionJuego excepcion que lanza si se produce un error.
     */
    @Override
    public void getFinishedRounds(String playeruuid, String orderByField, String group, RoundsCallback callback) throws ExcepcionJuego {
        List<Round> rounds = new ArrayList<>();
        RoundCursorWrapper cursor = queryRounds();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Round round = cursor.getRound();
            if (round.getPlayerUUID().equals(playeruuid))
                if (round.getBoard().getEstado() == TableroOthello.FINALIZADA)
                    rounds.add(round);
            cursor.moveToNext();
        }
        cursor.close();
        if (cursor.getCount() > 0)
            callback.onResponse(rounds);
    }

    /**
     * Metodo para obtener las rondas de un determinado usuario, devolviendo la lista obtenida.
     * @param playeruuid id del usuario que se quieren obtener las rondas.
     * @return lista de rondas obtenidas.
     */
    @Override
    public List<Round> getRounds(String playeruuid) {
        List<Round> rounds = new ArrayList<>();
        RoundCursorWrapper cursor = queryRounds();
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Round round = null;
            try {
                round = cursor.getRound();
            } catch (ExcepcionJuego excepcionJuego) {
                excepcionJuego.printStackTrace();
            }
            if (round.getPlayerUUID().equals(playeruuid))
                rounds.add(round);
            cursor.moveToNext();
        }
        cursor.close();

        return rounds;
    }

    /**
     * Metodo para obtener una ronda a partir de un id.
     * @param roundId id de la ronda.
     * @return ronda con id dado.
     */
    @Override
    public Round getRound(String roundId) {
        RoundCursorWrapper cursor = queryRounds();
        cursor.moveToFirst();
        boolean exists = false;
        Round round = null;
        while (!cursor.isAfterLast()) {
            try {
                round = cursor.getRound();
            } catch (ExcepcionJuego excepcionJuego) {
                excepcionJuego.printStackTrace();
            }
            if (round.getId().equals(roundId)) {
                exists = true;
                break;
            }
            cursor.moveToNext();
        }
        cursor.close();
        if (exists)
            return round;
        else
            return null;
    }

}
