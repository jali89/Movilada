/*
 * OthelloPreferenceFragment.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;

import es.uam.eps.dadm.othello_alejandromartin.R;
import es.uam.eps.dadm.othello_alejandromartin.model.RoundRepository;
import es.uam.eps.dadm.othello_alejandromartin.model.RoundRepositoryFactory;

/**
 * La clase OthelloPreferenceFragment es la actividad en la cual se muestra la lista
 * de preferencias.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class OthelloPreferenceFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener {

    /**
     * Metodo onCreate que crea la actividad cuando se llama a esta activity.
     * @param savedInstanceState objeto de tipo Builder que permite configurar la actividad.
     */
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings);

        onSharedPreferenceChanged(null, "");
        EditTextPreference etp = (EditTextPreference) findPreference("username");
        etp.setText(OthelloPreferenceActivity.getPlayerName(getActivity()));
        Preference helpPref = (Preference) findPreference("help");
        helpPref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Intent helpIntent = new Intent().setClass(
                        getActivity(), HelpActivity.class);
                startActivity(helpIntent);
                return true;
            }
        });

        Preference scoresPref = (Preference) findPreference("scores");
        scoresPref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Intent scoresIntent = new Intent().setClass(
                        getActivity(), ScoresActivity.class);
                startActivity(scoresIntent);
                return true;
            }
        });
    }

    /**
     * Metodo que se llama cuando se retoma la actividad.
     */
    @Override
    public void onResume() {
        super.onResume();
        // Set up a listener whenever a key changes
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    /**
     * Metodo que se llama cuando se pausa la actividad.
     */
    @Override
    public void onPause() {
        super.onPause();
        // Set up a listener whenever a key changes
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    /**
     * Metodo que gestiona cuando hay un cambio en una preferencia.
     * @param sharedPreferences preferencias.
     * @param key clave de la pref
     */
    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        switch (key) {
            case "username":
                EditTextPreference etp = (EditTextPreference) findPreference(key);
                RoundRepository repository = RoundRepositoryFactory.createRepository(getActivity());
                repository.updateUsername(OthelloPreferenceActivity.getPlayerUUID(getActivity()),
                        etp.getText(), OthelloPreferenceActivity.getPlayerPassword(getActivity()), null);
                OthelloPreferenceActivity.setPlayerName(getActivity(), etp.getText());
                break;
            case "validmoves":
                CheckBoxPreference cbp = (CheckBoxPreference) findPreference(key);
                if (cbp.isChecked()) {
                    OthelloPreferenceActivity.setValidMoves(getActivity(), true);
                    cbp.setChecked(true);
                }
                else {
                    OthelloPreferenceActivity.setValidMoves(getActivity(), false);
                    cbp.setChecked(false);
                }
                break;
        }
    }
}
