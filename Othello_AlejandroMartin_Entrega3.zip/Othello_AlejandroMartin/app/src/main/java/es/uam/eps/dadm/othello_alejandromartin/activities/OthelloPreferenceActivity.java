/*
 * OthelloPreferenceActivity.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.activities;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;

import es.uam.eps.dadm.othello_alejandromartin.R;

/**
 * La clase OthelloPreferenceActivity permite mostrar al usuario una actividad las preferencias
 * de la aplicacion.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class OthelloPreferenceActivity  extends AppCompatActivity {

    public final static String VALIDMOVES_KEY = "validmoves";
    public final static boolean VALIDMOVES_DEFAULT = true;

    public final static String PLAYERNAME_KEY = "playername";
    public final static String PLAYERNAME_DEFAULT = "Usuario";

    public final static String PLAYERUUID_KEY = "playeruuid";
    public final static String PLAYERUUID_DEFAULT = "0";

    public final static String PASSWORD_KEY = "password";
    public final static String PASSWORD_DEFAULT = "pass";

    /**
     * Metodo onCreate que crea la actividad cuando se llama a esta activity.
     * @param savedInstanceState objeto de tipo Builder que permite configurar la actividad.
     */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager
                .beginTransaction();
        OthelloPreferenceFragment fragment = new OthelloPreferenceFragment();

        fragmentTransaction.replace(android.R.id.content, fragment);
        fragmentTransaction.commit();
    }

    /**
     * Metodo para obtener si la opcion de mostrar movimientos validos esta activada.
     * @param context contexto en el que se encuentra la actividad.
     * @return boolean: true si esta activada, false en caso contrario.
     */
    public static boolean getValidMoves(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context)
                .getBoolean(VALIDMOVES_KEY, VALIDMOVES_DEFAULT);
    }

    /**
     * Metodo para activar o desactivar la opcione de movimientos validos.
     * @param context contexto en el que se encuentra la actividad.
     * @param on boolean para saber si se activa o desactiva la opcion.
     */
    public static void setValidMoves(Context context, boolean on) {
        SharedPreferences sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(OthelloPreferenceActivity.VALIDMOVES_KEY, on);
        editor.commit();
    }

    /**
     * Metodo para obtener el nombre de usuario del usuario de la aplicacion.
     * @param context contexto en el que se encuentra la actividad.
     * @return nombre del usuario de la aplicacion.
     */
    public static String getPlayerName(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context)
                .getString(PLAYERNAME_KEY, PLAYERNAME_DEFAULT);
    }

    /**
     * Metodo para poner un nuevo nombre de usuario al usuario de la aplicacion.
     * @param context contexto en el que se encuentra la actividad.
     * @param name nuevo nombre de usuario.
     */
    public static void setPlayerName(Context context, String name) {
        SharedPreferences sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(OthelloPreferenceActivity.PLAYERNAME_KEY, name);
        editor.commit();
    }

    /**
     * Metodo para obtener el id del usuario de la aplicacion.
     * @param context contexto en el que se encuentra la actividad.
     * @return id del usuario de la aplicacion.
     */
    public static String getPlayerUUID(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context)
                .getString(PLAYERUUID_KEY, PLAYERUUID_DEFAULT);
    }

    /**
     * Metodo para poner un nuevo id al usuario de la aplicacion.
     * @param context contexto en el que se encuentra la actividad.
     * @param playerId nuevo id del usuario.
     */
    public static void setPlayerUUID(Context context, String playerId) {
        SharedPreferences sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(OthelloPreferenceActivity.PLAYERUUID_KEY, playerId);
        editor.commit();
    }

    /**
     * Metodo para obtener la contrasena del usuario de la aplicacion.
     * @param context contexto en el que se encuentra la actividad.
     * @return contrasena del usuario de la aplicacion.
     */
    public static String getPlayerPassword(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context)
                .getString(PASSWORD_KEY, PASSWORD_DEFAULT);
    }

    /**
     * Metodo para poner la contrasena del usuario de la aplicacion.
     * @param context contexto en el que se encuentra la actividad.
     * @param password nueva contrasena del usuario.
     */
    public static void setPlayerPassword(Context context, String password) {
        SharedPreferences sharedPreferences = PreferenceManager
                .getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(OthelloPreferenceActivity.PASSWORD_KEY, password);
        editor.commit();
    }

}
