/*
 * Round.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.model;

import java.util.Date;
import java.util.UUID;

/**
 * La clase Round es la que define cada ronda.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class Round {

    private int size;
    private String id;
    private String title;
    private String date;
    private TableroOthello board;
    private String playerid;
    private String firstPlayerName;
    private String secondPlayerName;

    /**
     * Constructor de la clase Round.
     * @param size tamano del tablero de la ronda.
     * @param firstPlayerName nombre del primer jugador de la ronda.
     * @param playerid id del jugador de la ronda.
     */
    public Round(int size, String firstPlayerName, String playerid) {
        this.size = size;
        this.id = UUID.randomUUID().toString();
        this.title = "ROUND " + id.toString().substring(19, 23).toUpperCase();
        this.date = new Date().toString();
        this.board = new TableroOthello(size);
        this.firstPlayerName = firstPlayerName;
        this.secondPlayerName = "random";
        this.playerid = playerid;
    }

    /**
     * Metodo para obtener el tamano del tablero de la ronda.
     * @return tamano del tablero de la ronda.
     */
    public int getSize() { return size;}

    /**
     * Metodo para asignar un tamano de tablero a una ronda.
     * @param size tamano de tablero de la ronda.
     */
    public void setSize (int size) {
        this.size = size;
    }

    /**
     * Metodo para obtener el id de la ronda.
     * @return id de la ronda.
     */
    public String getId() {
        return this.id;
    }

    /**
     * Metodo para asignar un id a una ronda.
     * @param id a asignar.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Metodo para obtener el titulo de una ronda.
     * @return titulo de la ronda.
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Metodo par aasignar un titulo a una ronda.
     * @param title titulo de la ronda.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Metodo para ontener la fecha de la ronda.
     * @return fecha de la ronda.
     */
    public String getDate() {
        return this.date;
    }

    /**
     * Metodo para asignar una fecha a una ronda.
     * @param date fecha de la ronda.
     */
    public void setDate (String date) {
        this.date = date;
    }

    /**
     * Metodo para obtener el tablero de una ronda.
     * @return tablero de la ronda.
     */
    public TableroOthello getBoard() {
        return this.board;
    }

    /**
     * Metodo para asignar un tablero a una ronda.
     * @param board tablero de la ronda.
     */
    public void setBoard(TableroOthello board) {
        this.board = board;
    }

    /**
     * Metodo para obtener el id del usuario de la ronda.
     * @return id del usuario de la ronda.
     */
    public String getPlayerUUID () {
        return this.playerid;
    }

    /**
     * Metodo para asignar el id del usuario de una ronda.
     * @param playerId id del usuario a asignar.
     */
    public void setPlayerUUID (String playerId) {
        this.playerid = playerId;
    }

    /**
     * Metodo para asignar el nombre de usuario del primer jugador de la ronda.
     * @param firstPlayerName nombre del primer jugador de la ronda.
     */
    public void setFirstPlayerName(String firstPlayerName) {
        this.firstPlayerName = firstPlayerName;
    }

    /**
     * Metodo para obtener el nombre de usuario del primer jugador de la ronda.
     * @return nombre del primer jugador de la ronda.
     */
    public String getFirstPlayerName() {
        return this.firstPlayerName;
    }

    /**
     * Metodo para asignar el nombre de usuario del segundo jugador de la ronda.
     * @param secondPlayerName nombre del segundo jugador de la ronda.
     */
    public void setSecondPlayerName(String secondPlayerName) {
        this.secondPlayerName = secondPlayerName;
    }

    /**
     * Metodo para obtener el nombre de usuario del segundo jugador de la ronda.
     * @return nombre del segundo jugador de la ronda.
     */
    public String getSecondPlayerName() {
        return this.secondPlayerName;
    }
}
