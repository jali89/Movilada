/*
 * RoundRepositoryFactory.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.model;

import android.content.Context;

import es.uam.eps.dadm.othello_alejandromartin.database.OthelloDataBase;

/**
 * La clase RoundRepositoryFactory permite crear el repositorio de rondas.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class RoundRepositoryFactory {

    private static final boolean LOCAL = true;

    /**
     * Metodo para crear el repositorio de rondas.
     * @param context contexto en el que se crea.
     * @return repositorio de rondas creado.
     */
    public static RoundRepository createRepository(Context context) {

        RoundRepository repository;
        repository = LOCAL ? new OthelloDataBase(context) : new OthelloDataBase(context);

        try {
            repository.open();
        }
        catch (Exception e) {
            return null;
        }

        return repository;
    }

}
