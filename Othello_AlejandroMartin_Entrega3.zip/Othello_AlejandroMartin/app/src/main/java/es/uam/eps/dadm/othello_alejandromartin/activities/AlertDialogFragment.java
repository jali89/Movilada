/*
 * AlertDialogFragment.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.activities;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import es.uam.eps.dadm.othello_alejandromartin.R;
import es.uam.eps.dadm.othello_alejandromartin.model.Round;
import es.uam.eps.dadm.othello_alejandromartin.model.RoundRepository;
import es.uam.eps.dadm.othello_alejandromartin.model.RoundRepositoryFactory;
import es.uam.eps.dadm.othello_alejandromartin.views.OthelloView;

/**
 * La clase AlertDialogFragment permite mostrar al usuario una ventana flotante (dialogo)
 * para que pueda interaccionar con sus botones y seleccionar la opcion que crea conveniente,
 * una vez ha terminado la ronda.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class AlertDialogFragment  extends DialogFragment {

    final static int SIZE = 8;

    /**
     * Metodo para crear el dialogo. Crea el dialogo con las opciones que puede
     * seleccionar el usuario.
     * @param savedInstanceState objeto de tipo Builder que permite configurar el dialogo.
     */
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        final AppCompatActivity activity = (AppCompatActivity) getActivity();
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
        alertDialogBuilder.setTitle(R.string.game_over);

        // Se obtiene la vista del tablero
        OthelloView ov = (OthelloView) getActivity().findViewById(R.id.board_othelloview);

        // Puntos de los jugadores
        int puntos1 = ov.getBoard().getPuntosJug1(), puntos2 = ov.getBoard().getPuntosJug2();

        // Variable para obtener el ganador
        String winnerStr = "";

        // Se obtiene el ganador
        if (puntos1 > puntos2) {
            alertDialogBuilder.setMessage(getActivity().getText(R.string.winner) + " " +
                    ov.getFirstPlayerName().toString() +
                    "\n" + getActivity().getText(R.string.restart).toString());
        } else if (puntos2 > puntos1) {
            alertDialogBuilder.setMessage(getActivity().getText(R.string.winner) + " " +
                    ov.getSecondPlayerName().toString() +
                    "\n" + getActivity().getText(R.string.restart).toString());
        } else {
            // Si ha sido empate se manda el mensaje con Empate,
            // y se pregunta al usuario si quiere volver a jugar
            winnerStr = getActivity().getText(R.string.draw).toString();
            alertDialogBuilder.setMessage(winnerStr + "\n" +
                    getActivity().getText(R.string.restart).toString());
        }

        // Funcionalidad si el usuario pulsa el boton Yes
        alertDialogBuilder.setPositiveButton(getActivity().getText(R.string.yes),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                            final Round round = new Round(SIZE,
                                    OthelloPreferenceActivity.getPlayerName(getContext()),
                                    OthelloPreferenceActivity.getPlayerUUID(getContext()));
                            final RoundRepository repository = RoundRepositoryFactory.createRepository(getActivity());

                            repository.addRound(round, new RoundRepository.BooleanCallback() {
                                @Override
                                public void onResponse(boolean ok) {
                                    if (ok) {
                                        if (activity instanceof RoundListActivity) {
                                            ((RoundListActivity) activity).onRoundUpdated(round);

                                        }else {
                                            ((MainActivity) activity).finish();
                                        }
                                    } else
                                        Toast.makeText(activity, R.string.error_creating_round, Toast.LENGTH_SHORT).show();
                                }
                            });

                        dialog.dismiss();
                    }
                });

        // Funcionalidad si el usuario pulsa el boton No
        alertDialogBuilder.setNegativeButton(getActivity().getText(R.string.no),
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (activity instanceof MainActivity)
                            activity.finish();
                        dialog.dismiss();
                    }
                });

        return alertDialogBuilder.create();
    }

}
