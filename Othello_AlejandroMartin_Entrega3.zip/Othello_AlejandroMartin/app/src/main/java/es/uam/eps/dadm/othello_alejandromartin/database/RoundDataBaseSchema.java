/*
 * RoundDataBaseSchema.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.database;

/**
 * La clase RoundDataBaseSchema permite definir el esquema de la base de datos.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class RoundDataBaseSchema {

    /**
     * Tabla de usuarios.
     */
    public static final class UserTable {
        public static final String NAME = "users";
        public static final class Cols {
            public static final String PLAYERUUID = "playeruuid1";
            public static final String PLAYERNAME = "playername";
            public static final String PLAYERPASSWORD = "playerpassword";
        }
    }

    /**
     * Tabla de rondas.
     */
    public static final class RoundTable {
        public static final String NAME = "rounds";
        public static final class Cols {
            public static final String PLAYERUUID = "playeruuid2";
            public static final String ROUNDUUID = "rounduuid";
            public static final String DATE = "date";
            public static final String TITLE = "title";
            public static final String SIZE = "size";
            public static final String BOARD = "board";
        }
    }

}
