/*
 * RoundRepository.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.model;

import java.util.List;

import es.uam.eps.multij.ExcepcionJuego;

/**
 * RoundRepository es la interfaz atraves de la cual se conectara con la base de datos.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public interface RoundRepository {

    interface LoginRegisterCallback {
        void onLogin(String playerUuid);
        void onError(String error);
    }

    interface RoundsCallback {
        void onResponse(List<Round> rounds);
        void onError(String error);
    }

    interface BooleanCallback {
        void onResponse(boolean ok);
    }

    /**
     * Invoca al metodo getWritableDatabase que devuelve la referencia de tipo SQLiteDatabase,
     * para asi modificar los datos.
     * @throws Exception excepcion que lanza en caso de error.
     */
    void open() throws Exception;

    /**
     * Cierra la base de datos.
     */
    void close();

    /**
     * Metodo que se llama cuando un usuario hace login en el sistema.
     * @param playername nombre del usuario.
     * @param password password del usuario.
     * @param callback al cual se llamara una vez realizado el login.
     */
    void login(String playername, String password, LoginRegisterCallback callback);

    /**
     * Metodo que se llama cuando un usuario se registra en el sistema.
     * @param playername nombre del usuario.
     * @param password password del usuario.
     * @param callback al cual se llamara una vez realizado el registro.
     */
    void register(String playername, String password, LoginRegisterCallback callback);

    /**
     * Metodo para obtener las rondas de un determinado usuario.
     * @param playeruuid id del usuario que se quieren obtener las rondas.
     * @param orderByField orden en el que se quieren que se devuelvan.
     * @param group si se quieren agrupar.
     * @param callback al cual se llama una vez obtenidas las rondas.
     * @throws ExcepcionJuego excepcion que lanza si se produce un error.
     */
    void getRounds(String playeruuid, String orderByField, String group,
                   RoundsCallback callback) throws ExcepcionJuego;

    /**
     * Metodo para obtener las rondas de un determinado usuario que esten finalizadas.
     * @param playeruuid id del usuario que se quieren obtener las rondas.
     * @param orderByField orden en el que se quieren que se devuelvan.
     * @param group si se quieren agrupar.
     * @param callback al cual se llama una vez obtenidas las rondas finalizadas.
     * @throws ExcepcionJuego excepcion que lanza si se produce un error.
     */
    void getFinishedRounds(String playeruuid, String orderByField, String group,
                   RoundsCallback callback) throws ExcepcionJuego;

    /**
     * Metodo para obtener las rondas de un determinado usuario, devolviendo la lista obtenida.
     * @param playeruuid id del usuario que se quieren obtener las rondas.
     * @return lista de rondas obtenidas.
     */
    List<Round> getRounds(String playeruuid);

    /**
     * 	Anade a la base de datos la partida pasada como primer argumento.
     * @param round ronda para anadir a la base de datos.
     * @param callback al cual se llamara una vez anadida la ronda.
     */
    void addRound(Round round, BooleanCallback callback);

    /**
     * Metodo para obtener una ronda a partir de un id.
     * @param roundId id de la ronda.
     * @return ronda con id dado.
     */
    Round getRound(String roundId);

    /**
     * Metodo para actualizar una ronda de la base de datos.
     * @param round ronda que se quiere actualizar.
     * @param callback al cual se llamara una vez acutalizada la ronda.
     */
    void updateRound(Round round, BooleanCallback callback);

    /**
     * Metodo para actualizar un usuario de la base de datos.
     * @param playerid id del usuario que se quiere actualizar.
     * @param newUsername nombre de usuario del usuario que se quiere actualizar.
     * @param password contrasena del usuario que se quiere actualizar.
     * @param callback al cual se llamara una vez actualizado el usuario.
     */
    void updateUsername(String playerid, String newUsername, String password, BooleanCallback callback);

}
