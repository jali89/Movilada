/*
 * SplashActivity.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.activities;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Window;

import java.util.Timer;
import java.util.TimerTask;

import es.uam.eps.dadm.othello_alejandromartin.R;

/**
 * La clase SplashActivity permite mostrar al usuario una actividad con una imagen
 * mientras que se carga la aplicacion.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class SplashActivity extends Activity {

    private static final long SPLASH_SCREEN_DELAY = 2000;

    /**
     * Metodo onCreate que crea la actividad cuando se llama a esta activity.
     * @param savedInstanceState objeto de tipo Builder que permite configurar la actividad.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_splash);

        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Intent loginIntent = new Intent().setClass(
                        SplashActivity.this, LoginActivity.class);
                startActivity(loginIntent);

                finish();
            }
        };

        Timer timer = new Timer();
        timer.schedule(task, SPLASH_SCREEN_DELAY);
    }

}
