/*
 * ScoresActivity.java
 *
 * By Alejandro Antonio Martin Almansa
 */

package es.uam.eps.dadm.othello_alejandromartin.activities;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import es.uam.eps.dadm.othello_alejandromartin.R;

/**
 * La clase ScoresActivity permite mostrar al usuario una actividad con todas las rondas
 * finalizadas.
 *
 * @author Alejandro Antonio Martin Almansa
 */
public class ScoresActivity extends AppCompatActivity {

    /**
     * Metodo para crear la actividad gestora de fragmentos y de transacciones.
     * @param savedInstanceState objeto de tipo Builder que permite configurar el gestor.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_masterdetail);
        FragmentManager fm = getSupportFragmentManager();
        Fragment fragment = fm.findFragmentById(R.id.fragment_container);
        if (fragment == null) {
            fragment = new ScoresFragment();
            fm.beginTransaction()
                    .add(R.id.fragment_container, fragment)
                    .commit();
        }
    }
}
